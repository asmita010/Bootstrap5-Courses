<?php

session_start();
ini_set('display_errors',0);

?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]>      <html class="no-js"> <!--<![endif]-->
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="cs/home.css">

        

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@500&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Roboto+Mono:wght@300&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300&display=swap" rel="stylesheet">

        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
        
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/js/bootstrap.min.js" integrity="sha384-oesi62hOLfzrys4LxRF63OJCXdXDipiYWBnvTl9Y9/TRlw5xlKIEHpNyvvDShgf/" crossorigin="anonymous"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
        <link href="https://fonts.googleapis.com/css2?family=Georama:wght@300&display=swap" rel="stylesheet">

    </head>
    <body>
       
        <div>
            <nav class="navbar navbar-expand-md navbar-dark bg-dark mb-lg-2 mb-3 ">
                <div class="container-fluid">
                    <a class="navbar-brand" href="#">
                        <span class="bi bi-code-slash text-primary" style="font-size: 2rem;"> Coursez</span>
                        
                    </a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse justify-content-center" id="navbarSupportedContent">
                        
                        <ul class="navbar-nav  mb-2 mb-lg-0 ">
                            <li class="nav-item si mx-md-2 mx-lg-4">
                                <a class="nav-link active" class="si" aria-current="page" href="#">Home</a>
                            </li>
                            <li class="nav-item mx-md-2 mx-lg-4 si">
                                <a class="nav-link" class="si" href="#c">Courses we offer</a>
                            </li>
                            <li class="nav-item mx-md-2 mx-lg-4 si">
                                


                            
                               


                            <?php

                                if(!isset($_SESSION['username'])) {
                                    
                                    echo '<a class="nav-link ms-a" class="si" href="landing_page.php">Log In / Sign In</a>';
                                }
                                else {
                                    echo '<a class="nav-link ms-a" class="si" href="logout.php">Log Out</a>';
                                }
                                ?>
                            </li>  
                        </ul>
                    </div>
                </div>
            </nav>
        </div>  
        
        <div class="container ">  
            <div class="d-flex  justify-content-center d-none d-lg-block mt-lg-4">
                <div class=" d-flex   align-items-center flex-column">
                    
                    <div class="h2 ">Coursez</div>
                </div>
            </div> 


            <div class="container mt-3 rounded bg-secondary">
                <div class="  d-flex align-items-center flex-column  py-4 py-lg-5">
                    <i class="bi bi-hand-thumbs-up display-4 text-primary mb-lg-2 "></i>
                    <h3 class="text-teal text-center my-3 ">Sign Up and get access to our NEWSLETTER</h3>
                    <a class="btn btn-primary mt-1 btn-lg  mt-lg-3 mt-2" href="landing_page.php">Sign Up</a>
                </div>
            </div>
            
            <div classs="container ">
                <div class= "my-5  d-flex align-items-center flex-column">
                <h2 class="text-dark strong ">About Us</h2>
                    <div class="text-center border border-3 border-warning">
                    <blockquote class="blockquote px-2 pt-2 px-2">
                        <p>We started this journey 10 years back with only one mission-To help millions of students by providing free educational/technical content.
                        Today, we are a team of almost 100 prfessionals increasing the outreach of technical educational pan the globe.
                        Our customers have always been supportive and encouraged us.</p>
                        <p>We hope to never let you down.</p>
                    </blockquote>
                    </div>
                </div>
            </div>

            <div class="container" id="c">
                <div class="  d-flex align-items-center flex-column ">
                    <h2 class="strong">Courses Offered</h2>
                    
                    
                    <div class="card mb-3 size border-warning border-3 px-lg-5">
                                    <div class="row gy-2 r px-lg-5 py-lg-3">
                                        <div class="col-lg-12 d-flex align-center px-xxl-5">
                                            <img src="images/android.png" class=" p-3 img-fluid" alt="...">
                                        </div>
                                    </div>
                                    <div class="row gy-2 r">
                                        <div class="col-lg-12">
                                            <div class="card-body">
                                                <h5 class="card-title text-center mb-3 border-bottom border-info border-3 pb-2">Android development</h5>
                                                <p class="card-text text-center text-sm-start">
                                                Android software development is the process by which applications are created for devices running the Android operating system. Google states that "Android apps can be written using Kotlin, Java, and C++ languages" using the Android software development kit, while using other languages is also possible.
                                                </p>
                                                <p class="card-text text-center">
                                                    <button class="btn btn-outline-primary ">
                                                        View Course</button>
                                                    <span class="ms-2">$80</span>
                                                </p>
                                            </div>
                                        </div>
                                        </div>
                                    </div>

                                    <div class="card mb-3 size border-warning border-3 px-lg-5">
                                    <div class="row gy-2 r px-lg-5 py-lg-3">
                                        <div class="col-lg-12 d-flex align-center px-xxl-5">
                                            <img src="images/flutter.png" class=" p-3 img-fluid" alt="...">
                                        </div>
                                    </div>
                                    <div class="row gy-2 r">
                                        <div class="col-lg-12">
                                            <div class="card-body">
                                                <h5 class="card-title text-center mb-3 border-bottom border-info border-3 pb-2">Flutter</h5>
                                                <p class="card-text text-center text-sm-start">
                                                Flutter is an open-source UI software development kit created by Google. It is used to develop cross platform applications for Android, iOS, Linux, Mac, Windows, Google Fuchsia, and the web from a single codebase. The first version of Flutter was known as codename "Sky" and ran on the Android operating system.
                                                Flutter builds from a single codebase, compile directly to the native arm code, Use the GPU and access the platform APIs and services.
                                                </p>
                                                <p class="card-text text-center">
                                                    <button class="btn btn-outline-primary ">
                                                        View Course</button>
                                                    <span class="ms-2">$60</span>
                                                </p>
                                            </div>
                                        </div>
                                        </div>
                                    </div>

                                    <div class="card mb-3 size border-warning border-3 px-lg-5">
                                    <div class="row gy-2 r px-lg-5 py-lg-3">
                                        <div class="col-lg-12 d-flex align-center px-xxl-5">
                                            <img src="images/node.png" class=" p-3 img-fluid" alt="...">
                                        </div>
                                    </div>
                                    <div class="row gy-2 r">
                                        <div class="col-lg-12">
                                            <div class="card-body">
                                                <h5 class="card-title text-center mb-3 border-bottom border-info border-3 pb-2">  Node.js </h5>
                                                <p class="card-text text-center text-sm-start">
                                                Node.js is an open-source, cross-platform, back-end JavaScript runtime environment that runs on the V8 engine and executes JavaScript code outside a web browser.
                                                
Node. js is primarily used for non-blocking, event-driven servers, due to its single-threaded nature. It's used for traditional web sites and back-end API services, but was designed with real-time, push-based architectures in mind.
                                                </p>
                                                <p class="card-text text-center">
                                                    <button class="btn btn-outline-primary ">
                                                        View Course</button>
                                                    <span class="ms-2">$100</span>
                                                </p>
                                            </div>
                                        </div>
                                        </div>
                                    </div>

                                    
                    
                            <?php
                                $db = mysqli_connect('localhost','root');
                               
                                if($db){
                                    mysqli_select_db($db,'courses_accounts');
                                    $result = mysqli_query($db, "SELECT * FROM courses");
                                while ($row = mysqli_fetch_array($result)) {
                                    echo "<div class='card mb-3 size border-warning border-3 px-lg-5'>";
                                    echo "<div class='row gy-2 r px-lg-5 py-lg-3'>";
                                    echo "<div class='col-lg-12 d-flex align-center px-xxl-5'>";
                                    
                                    echo "<img src='images/".$row['image']."' class=' p-3 img-fluid' alt='...'>";
                                    echo "</div>";
                                    echo "</div>";
                                    echo "<div class='row gy-2 r'>";
                                    echo "<div class='col-lg-12'>";
                                        echo "<div class='card-body'>";
                                            echo "<h5 class='card-title text-center mb-3 border-bottom border-info border-3 pb-2'>".$row['title']."</h5>";

                                            echo "<p class='card-text text-center text-sm-start'>".$row['info']."</p>";

                                            echo "<p class='card-text text-center'>";
                                                echo "<button class='btn btn-outline-primary ''>View Course</button>";
                                                echo "<span class='ms-2'>$".$row['price']."</span>";
                                                echo "</p>";
                                                echo "</div>";
                                                echo "</div>";
                                                echo "</div>";
                                                echo "</div>";
                                            }
                                        }
                                    ?>

                                    
                           

                   
                    


                </div>
            </div>


        </div>


        <script src="home.js" async defer></script>
    </body>
</html>