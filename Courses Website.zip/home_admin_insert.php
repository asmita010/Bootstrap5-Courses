function func() {

        
<?php
session_start();
header('location:home_admin.php');
// Create database connection
$db = mysqli_connect("localhost", "root", "", "courses_accounts");

// Initialize message variable
$msg = "";
$image_text="";
$image="";


$title = mysqli_real_escape_string($db, $_POST['ntitle']);
 $info = mysqli_real_escape_string($db, $_POST['ndesc']);
 $price = mysqli_real_escape_string($db, $_POST['nprice']);
 //Get image
// Get image name
$image = $_FILES['image']['name'];

// image file directory
$target = "images/".basename($image);

$sql = "INSERT INTO courses(title,info,price,image) VALUES ('$title','$info','$price','$image')";  
// execute query
mysqli_query($db, $sql);

if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
 $msg = "Image uploaded successfully";
 $image="";
 $image_text="";
}else{
 $msg = "Failed to upload image";
}


?>

}