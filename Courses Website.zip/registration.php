<?php

session_start();
header('location:landing_page.php');
$con = mysqli_connect('localhost','root');
if($con){
    echo "Connected";
    
}
else {
    echo "NOT CONNECTED";
}

mysqli_select_db($con,'courses_accounts');

$name = $_POST['signin_username'];
$pass = $_POST['signin_password'];
$email = $_POST['signin_email'];

$q = "select * from accounts where username='$name' && password='$pass' ";
$result = mysqli_query($con,$q);
$num = mysqli_num_rows($result);

if($num ==1){
    echo "Enter different credentials";
}
else {
    
    $query = "insert into accounts(username,password,email) values('$name','$pass','$email')";
    $result = mysqli_query($con,$query);
}
?>