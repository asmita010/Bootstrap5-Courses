<?php

session_start();

?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]>      <html class="no-js"> <!--<![endif]-->
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="cs/landing_page_style.css">

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@500&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Roboto+Mono:wght@300&display=swap" rel="stylesheet">

        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/js/bootstrap.min.js" integrity="sha384-oesi62hOLfzrys4LxRF63OJCXdXDipiYWBnvTl9Y9/TRlw5xlKIEHpNyvvDShgf/" crossorigin="anonymous"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
        <link href="https://fonts.googleapis.com/css2?family=Georama:wght@300&display=swap" rel="stylesheet">

    </head>
    <body>
        <!--[if lt IE 7]>
            <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="#">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

    <div>
        <nav class="navbar navbar-expand-md navbar-dark bg-dark mb-lg-2 mb-3 ">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">
                    <span class="bi bi-code-slash text-primary" style="font-size: 2rem;"> Coursez</span>
                    
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-center" id="navbarSupportedContent">
                    
                    <ul class="navbar-nav  mb-2 mb-lg-0 ">
                        <li class="nav-item si mx-md-2 mx-lg-4">
                            <a class="nav-link " aria-current="page" href="home.php">Home</a>
                        </li>
                        <li class="nav-item mx-md-2 mx-lg-4 si">
                            <a class="nav-link" href="home.php#c">Courses we offer</a>
                        </li>
                        <li class="nav-item mx-md-2 mx-lg-4 si">
                            <a class="nav-link  active ms-a" href="#">Log In / Sign In</a>
                        </li>  
                    </ul>
                </div>
            </div>
        </nav>
    </div>
    
   
    <div class="alig  d-flex justify-content-center">
        <div class="row  align-items-center mx-2">
            <div class=" bg-secondary text-warning p-4 rounded padding" >
                <div class="container mb-3 mb-md-2">
                <div class="btn-group" role="group" aria-label="Basic mixed styles example">
                    <button type="button" id="bsignin" class="btn color  btn text-danger fon">Sign Up</button>
                    <button type="button" id="blogin" class="btn btn-dark bg-gradient text-danger btn fon">Log In</button>
                </div>
                </div>
                <div class="mb-md-5 mb-4 mt-lg-4 ">    
                    <h1 class="text-primary">Coursez</h1>
                    <h3 class="text-dark">Wide Range of Online Courses</h3>
                </div>

                <form id="signin" action="registration.php" method="POST">
                    <div class="mb-4 ">
                        <label for="signin_username" class="f form-label h4">Enter Username</label>
                        <input type="text" class="form-control" name="signin_username" placeholder="Username" required> 
                    </div> 
                    <div class="mb-4">
                        <label name="signin_password" class="f form-label h4">Enter Password</label>
                        <input type="password" name="signin_password" class="form-control" placeholder="Password" required aria-describedby="passwordHelpBlock">
                    </div>
                    <div class="mb-4 ">
                        <label for="signin_email" class="f form-label h4">Enter E-mail Address</label>
                        <input type="text" class="form-control" name="signin_email" placeholder="E-mail Address" required> 
                    </div> 
                    <button class="btn  btn-outline-warning btn-lg mb-lg-2 mt-2"  type="submit">Create Account</button>
                </form>
                
                <form id="login" action="validation.php" method="POST">
                    <div class="mb-4 ">
                        <label for="login_username" class="f form-label h4">Enter Username</label>
                        <input type="text" class="form-control" name="login_username" placeholder="Username"> 
                    </div> 
                    <div class="mb-4">
                        <label for="login_password" class="f form-label h4">Enter Password</label>
                        <input type="password" name="login_password" class="form-control" placeholder="Password" aria-describedby="passwordHelpBlock">
                    </div>
                    <button class="btn  btn-outline-warning btn-lg mb-lg-2 mt-2" type="submit">Log In</button>
                </form>
 
            </div>      
        </div>
    </div>

        
        
        <script type="text/javascript" src="js/landing_page_javascript.js" async defer></script>
    </body>
</html>