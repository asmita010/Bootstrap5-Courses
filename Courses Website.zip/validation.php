<?php

session_start();
header('location:landing_page.php');
$con = mysqli_connect('localhost','root');
if($con){
    echo "Connected";
}
else {
    echo "NOT CONNECTED";
}

mysqli_select_db($con,'courses_accounts');

$name = $_POST['login_username'];
$pass = $_POST['login_password'];

$q = "select * from accounts where username='$name' && password='$pass' ";
$result = mysqli_query($con,$q);
$num = mysqli_num_rows($result);
if($num ==1){

    $_SESSION['username'] = $name;
   
    if ($name == "admin")
    {
        header('location:home_admin.php');
    }
else {
        header('location:home.php');
}
}
else {
   header('location:landing_page.php');
}

?>